from django.shortcuts import render, redirect
from .models import StudyPlan

def home(request):
    plans = StudyPlan.objects.all().order_by('-id')
    return render(request, 'tracker/home.html', {'plans': plans})

def add_task(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        subject = request.POST.get('subject')
        study_date = request.POST.get('study_date')
        duration = request.POST.get('duration')
        
        if title and subject and study_date and duration:
            StudyPlan.objects.create(
                title=title,
                subject=subject,
                study_date=study_date,
                duration=duration
            )
    return redirect('home')

def toggle_task(request, task_id):
    try:
        task = StudyPlan.objects.get(id=task_id)
        task.completed = not task.completed
        task.save()
    except StudyPlan.DoesNotExist:
        pass
    return redirect('home')

def delete_task(request, task_id):
    try:
        task = StudyPlan.objects.get(id=task_id)
        task.delete()
    except StudyPlan.DoesNotExist:
        pass
    return redirect('home')
