from django.db import models


class StudyPlan(models.Model):
    title = models.CharField(max_length=200)
    subject = models.CharField(max_length=100)
    study_date = models.DateField()
    duration = models.IntegerField()  # in minutes
    completed = models.BooleanField(default=False)

    def __str__(self):
        return self.title

# Create your models here.
